# packagecp

Description. 
The package packagecp is used to:
	- Calculate 
	- Porcentagem
utils: 
    -aumentar %
	-reducao %

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install packagecp

```bash
pip install packagecp
```

## Usage

```python
from packagecp.utils.calc_preco import aumento, reducao 
from package.formatar import output
aumento.() 
reducao.()
```

## Author
WilliamMoura

## License
[MIT](https://choosealicense.com/licenses/mit/)